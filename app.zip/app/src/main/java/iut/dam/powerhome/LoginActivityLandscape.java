package iut.dam.powerhome;

import android.app.Activity;

public class LoginActivityLandscape extends Activity {
}
